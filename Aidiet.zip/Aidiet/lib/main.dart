import 'package:flutter/material.dart';
import 'package:aidiet/menuModel.dart';
import 'package:flutter/services.dart';
import 'menuModel.dart';
import 'menulist.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "My home",
      theme: ThemeData(
          scaffoldBackgroundColor: Colors.white,
          primarySwatch: Colors.green,
          fontFamily: 'Montserrat'),
      home: Welcome(),
    );
  }
}

class Welcome extends StatefulWidget {
  Welcome({Key key, this.title}) : super(key: key);
  final String title;
  @override
  _Welcome createState() => _Welcome();
}

class _Welcome extends State<Welcome> {
  final weightController = TextEditingController();
  final heightController = TextEditingController();
  final sexController = TextEditingController();
  final ageController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double buttonW = width * 0.5;
    final submit = Material(
      elevation: 3.0,
      borderRadius: BorderRadius.circular(10.0),
      color: Colors.green,
      child: MaterialButton(
        minWidth: buttonW,
        height: 2,
        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Menulist(
                    // model: menuModel(),
                    weight: int.parse(weightController.text),
                    height: int.parse(heightController.text),
                    sex: sexController.text,
                    age: int.parse(ageController.text)
                    )
                    ),
          );
        },
        child: Text("Submit",
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16)),
      ),
    );
    final sex = Material(
      elevation: 3.0,
      borderRadius: BorderRadius.circular(10.0),
      color: Colors.white,
      child: MaterialButton(
        minWidth: buttonW,
        height: 2,
        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
        child: TextField(
          controller: sexController,
          decoration: new InputDecoration(labelText: "Male(M) or Female(F)"),
          // Only numbers can be entered
        ),
      ),
    );
    final weight = Material(
      elevation: 3.0,
      borderRadius: BorderRadius.circular(10.0),
      color: Colors.white,
      child: MaterialButton(
        minWidth: buttonW,
        height: 2,
        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
        child: TextField(
          controller: weightController,
          decoration: new InputDecoration(labelText: "Enter weight"),
          keyboardType: TextInputType.number,
          inputFormatters: <TextInputFormatter>[
            FilteringTextInputFormatter.digitsOnly
          ], // Only numbers can be entered
        ),
      ),
    );
    final height = Material(
      elevation: 3.0,
      borderRadius: BorderRadius.circular(10.0),
      color: Colors.white,
      child: MaterialButton(
        minWidth: buttonW,
        height: 2,
        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
        child: TextField(
          controller: heightController,
          decoration: new InputDecoration(labelText: "Enter height"),
          keyboardType: TextInputType.number,
          inputFormatters: <TextInputFormatter>[
            FilteringTextInputFormatter.digitsOnly
          ], // Only numbers can be entered
        ),
      ),
    );
    final age = Material(
      elevation: 3.0,
      borderRadius: BorderRadius.circular(10.0),
      color: Colors.white,
      child: MaterialButton(
        minWidth: buttonW,
        height: 2,
        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
        child: TextField(
          controller: ageController,
          decoration: new InputDecoration(labelText: "Enter age"),
          keyboardType: TextInputType.number,
          inputFormatters: <TextInputFormatter>[
            FilteringTextInputFormatter.digitsOnly
          ], // Only numbers can be entered
        ),
      ),
    );
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(36.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  height: 150,
                  child: Image.asset(
                    "assets/image/logo.png",
                    fit: BoxFit.contain,
                  ),
                ),
                SizedBox(
                  height: 40.0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        "AI",
                        style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.bold,
                            color: Colors.greenAccent[700]),
                      ),
                      Text(
                        "diet",
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.green[800]),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                sex,
                SizedBox(
                  height: 10,
                ),
                height,
                SizedBox(
                  height: 10,
                ),
                weight,
                SizedBox(
                  height: 10,
                ),
                age,
                SizedBox(
                  height: 10,
                ),
                submit,
              ],
            ),
          ),
        ),
      ),),
    );
  }
}
