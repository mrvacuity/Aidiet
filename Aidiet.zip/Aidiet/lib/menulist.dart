import 'package:flutter/material.dart';
import 'package:aidiet/menu.dart';
import 'package:aidiet/menuModel.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:aidiet/listpage.dart';
import 'package:aidiet/Showdetail.dart';

class Menulist extends StatelessWidget {
  // This widget is the root of your application.
  // final menuModel model;
  final int weight;
  final int height;
  final String sex;
  final int age;
  const Menulist({
    Key key, 
    // @required this.model, 
    @required this.weight, 
    @required this.height, 
    @required this.sex,
    @required this.age
    }) : super(key: key);
  calculateCal(int h,int w, String s, int a){
    double kcal = 0;
    if( s == 'M' || s == 'm' || s == 'male' || s == 'Male'){
      double temp = 5.0*h;
      kcal = 66+ (13.7 * w) + temp - (6.8*a) ;
    } else {
      kcal = 665+ (9.6 * w) + 1.8*h - (4.7*a);
    }
    return kcal;
  }
  
  @override
  Widget build(BuildContext context) {
    return ScopedModel<menuModel>(
      model: menuModel(calculateCal(height, weight, sex, age)),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Menu list',
        home: ListScreen(),
        routes: {'/list': (context) => listPage()},
      ),
    );
  }
}

class ListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      backgroundColor: Colors.white,
      appBar:
      AppBar(
        backgroundColor: Colors.green,
        actions: <Widget>[
          
          FlatButton(
              child: Text("Clear", style: TextStyle(color: Colors.white),),
              onPressed: () => ScopedModel.of<menuModel>(context).clearlist()),
          IconButton(
            icon: Icon(Icons.food_bank),
            onPressed: () => Navigator.pushNamed(context, '/list'),
          ),
        ],
        title: Text('Kcal: '+ ScopedModel.of<menuModel>(context,rebuildOnChange: true).totallistValue.toStringAsFixed(2) ),
      ),
      body: ListView.builder(
        itemExtent: 100,
        itemCount: itemList.length,
        itemBuilder: (context, index) {
          return ScopedModelDescendant<menuModel>(
              builder: (context, child, model) {
                return ListTile(
                  leading: Image.asset(itemList[index].imagePath , height: 150, width: 50, fit: BoxFit.fitWidth,),
                  title: Text(itemList[index].title),
                  subtitle: Text(itemList[index].cal.toString()+" Kcal"+"\n Click more detail"),
                  trailing: OutlineButton(
                      child: Text("Add"),
                      onPressed: () => model.addProduct(itemList[index])),
                  onTap: (){
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>  DetailPage(itemList[index])));
                  },
                );
              });
        },
      ),
    );
  }
  
}
