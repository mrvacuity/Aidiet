import 'package:aidiet/menu.dart';
import 'package:scoped_model/scoped_model.dart';
class menuModel extends Model {
  double totalKcal;
  menuModel(this.totalKcal);
  List<Menu> list = [];
  int get total => list.length;
  double totallistValue = 0;
  void addProduct(item) {
    int index = list.indexWhere((i) => i.id == item.id);
    print(index);
    if (index != -1)
      updateProduct(item, item.qty + 1);
    else {
      list.add(item);
      calculateTotal();
      notifyListeners();
    }
  }

  void removeProduct(item) {
    int index = list.indexWhere((i) => i.id == item.id);
    list[index].qty = 1;
    list.removeWhere((item) => item.id == item.id);
    calculateTotal();
    notifyListeners();
  }

  void updateProduct(item, qty) {
    int index = list.indexWhere((i) => i.id == item.id);
    list[index].qty = qty;
    if (list[index].qty == 0)
      removeProduct(item);

    calculateTotal();
    notifyListeners();
  }

  void clearlist() {
    list.forEach((f) => f.qty = 1);
    list = [];
    totallistValue = totalKcal;
    notifyListeners();
  }

  void calculateTotal() {
    totallistValue = totalKcal;
    list.forEach((f) {
      totallistValue -= f.qty * f.cal;
    });
  }
}

class Product {
  int id;
  String title;
  String imagePath;
  String info;
  double cal;
  int qty;
  Product({this.id, this.title, this.imagePath, this.info, this.cal, this.qty});
}
