import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:aidiet/menuModel.dart';


class listPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _listPageState();
  }
}
class _listPageState extends State<listPage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.green,
          title: Text("Selected Menu"),
          actions: <Widget>[
            FlatButton(
                child: Text(
                  "Clear",
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () => ScopedModel.of<menuModel>(context).clearlist())
          ],
        ),
        body: ScopedModel.of<menuModel>(context, rebuildOnChange: true)
                    .list
                    .length ==
                0
            ? Center(
                child: Text("No menu in List"),
              )
            : Container(
                padding: EdgeInsets.all(8.0),
                child: Column(children: <Widget>[
                  Expanded(
                    child: ListView.builder(
                      itemCount: ScopedModel.of<menuModel>(context,
                              rebuildOnChange: true)
                          .total,
                      itemBuilder: (context, index) {
                        return ScopedModelDescendant<menuModel>(
                          builder: (context, child, model) {
                            return ListTile(
                              title: Text(model.list[index].title),
                              subtitle: Text(model.list[index].qty.toString() +
                                  " x " +
                                  model.list[index].cal.toString() +
                                  " = " +
                                  (model.list[index].qty *
                                          model.list[index].cal)
                                      .toString()),
                              trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      icon: Icon(Icons.add),
                                      onPressed: () {
                                        model.updateProduct(model.list[index],
                                            model.list[index].qty + 1);
                                        // model.removeProduct(model.list[index]);
                                      },
                                    ),
                                    IconButton(
                                      icon: Icon(Icons.remove),
                                      onPressed: () {
                                        model.updateProduct(model.list[index],
                                            model.list[index].qty - 1);
                                        // model.removeProduct(model.list[index]);
                                      },
                                    ),
                                  ]),
                            );
                          },
                        );
                      },
                    ),
                  ),
                  Container(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "Total: " +
                            ScopedModel.of<menuModel>(context,
                                    rebuildOnChange: true)
                                .totallistValue
                                .toStringAsFixed(2) +
                            " Kcal",
                        style: TextStyle(
                            fontSize: 24.0, fontWeight: FontWeight.bold),
                      )),
                ])));
  }
}
