package com.example.movie_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
